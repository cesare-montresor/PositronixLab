# ModularNet: Ray Integration - Visual Diagrams

## System Architecture Diagram

```
┌────────────────────────────────────────────────────────────────────┐
│                        User Application                            │
│                  (pipeline_train.py, trials)                       │
└────────────────────────┬─────────────────────────────────────────┘
                         │
                         │ instantiates
                         ▼
        ┌────────────────────────────────┐
        │     PluginManager              │
        │  (High-Level User API)         │
        │                                │
        │ Methods:                       │
        │  • load_plugin()               │
        │  • start_plugin()              │
        │  • stop_plugin()               │
        │  • publish()                   │
        │  • set_env_variable()          │
        │  • invoke_service()            │
        │  • start_processing_loop()     │
        └────────────────┬───────────────┘
                         │
              ray.init() │ ray.is_initialized()
                         │ PluginOrchestrator.remote()
                         │
                         ▼
        ┌────────────────────────────────────────────────┐
        │   PluginOrchestrator (@ray.remote)             │
        │   (Central Distributed Actor in Ray)           │
        │                                                │
        │ Manages:                                       │
        │  • _plugins: {id: ActorHandle}                │
        │  • _topics: {name: [Queue]}                   │
        │  • _env_subscriptions: {key: [plugin_ids]}   │
        │  • env_manager: EnvironmentManager             │
        │                                                │
        │ Methods:                                       │
        │  • register_plugin()   [ray.actor.ActorHandle] │
        │  • subscribe()         [ray.util.queue.Queue]  │
        │  • publish()           → deliver to all queues │
        │  • set_env_variable()  → broadcast updates     │
        │  • invoke_service()    → route to target plugin │
        └────────┬──────────────┬───────────────┬────────┘
                 │              │               │
         register_plugin()   subscribe()    multiple refs
                 │              │               │
    ┌────────────┴────────────┐ │ ┌───────────┴─────────────┐
    │                         │ │ │                         │
    │ ray.get(               │ │ │                         │
    │   .register_plugin     │ │ │                         │
    │   .remote())           │ │ │                         │
    │                         │ │ │                         │
    ▼                         ▼ ▼ ▼                         
┌─────────────────┐  ┌──────────────────┐  ┌─────────────────┐
│ PluginHandler 1 │  │ PluginHandler 2  │  │ PluginHandler N │
│ (@ray.remote)   │  │ (@ray.remote)    │  │ (@ray.remote)   │
│                 │  │                  │  │                 │
│ Actor Instance  │  │ Actor Instance   │  │ Actor Instance  │
│                 │  │                  │  │                 │
│ Methods:        │  │ Methods:         │  │ Methods:        │
│ • load_plugin() │  │ • load_plugin()  │  │ • load_plugin() │
│ • start()       │  │ • start()        │  │ • start()       │
│ • stop()        │  │ • stop()         │  │ • stop()        │
│ • receive_env   │  │ • receive_env    │  │ • receive_env   │
│   _update()     │  │   _update()      │  │   _update()     │
│ • execute_      │  │ • execute_       │  │ • execute_      │
│   service()     │  │   service()      │  │   service()     │
│ • process_      │  │ • process_       │  │ • process_      │
│   messages()    │  │   messages()     │  │   messages()    │
└────────┬────────┘  └────────┬─────────┘  └────────┬────────┘
         │                    │                     │
    loads/runs            loads/runs             loads/runs
         │                    │                     │
         ▼                    ▼                     ▼
    ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
    │ BasePlugin 1 │  │ BasePlugin 2 │  │ BasePlugin N │
    │              │  │              │  │              │
    │ User Plugin  │  │ User Plugin  │  │ User Plugin  │
    │              │  │              │  │              │
    │ • on_start() │  │ • on_start() │  │ • on_start() │
    │ • on_stop()  │  │ • on_stop()  │  │ • on_stop()  │
    │ • callbacks  │  │ • callbacks  │  │ • callbacks  │
    └──────────────┘  └──────────────┘  └──────────────┘
```

---

## Data Flow: Pub/Sub Example

```
Timeline: DeepLearning Setup → Train Workflow

T=0: User loads plugins
┌─────────────────────────────┐
│ manager.load_plugin(        │
│   SetupPluginDescriptor     │
│ )                           │
└──────────┬──────────────────┘
           │
           ▼ ray.get(.load_plugin.remote(descriptor))
    PluginHandler deserializes, imports,
    instantiates SetupPlugin
           │
           │
T=1: User loads second plugin
┌─────────────────────────────┐
│ manager.load_plugin(        │
│   TrainPluginDescriptor     │
│ )                           │
└──────────┬──────────────────┘
           │
           ▼ ray.get(.load_plugin.remote(descriptor))
    PluginHandler deserializes, imports,
    instantiates TrainPlugin
           │ get_env_subscriptions()
           │   → [Subscription("model", "on_model_changed")]
           │   → [Subscription("dataprovider", "on_dp_changed")]
           │
           ▼ PluginOrchestrator.subscribe_env("model", "train-plugin")
    _env_subscriptions["model"] = ["train-plugin"]


T=2: User starts plugins
┌─────────────────────────────────┐
│ manager.start_plugin("setup")    │
└──────────┬──────────────────────┘
           │
           ▼ ray.get(.start.remote())
    SetupPlugin.on_start()
           │
           ├─ model = MetaModel(...)
           ├─ dataprovider = DataProvider(...)
           │
           └─ self.set_env_variable("model", model)
                     │
                     ▼ ray.get(.set_env_variable.remote("model", model))
                PluginOrchestrator receives
                _env_subscriptions["model"] = ["train-plugin"]
                           │
                           ▼ ray.get(PluginHandler[train].receive_env_update.remote(...))
                        receive_env_update(EnvUpdate(key="model", value=model))
                           │
                           ├─ self._local_env["model"] = model
                           │
                           └─ call on_model_changed(update)
                                     │
                                     ▼ TrainPlugin.on_model_changed()
                                        self.model = update.value
                                        check_and_start_training()
                                           │
                                           ├─ model = ✓ (now has it)
                                           ├─ dataprovider = ? (waiting)
                                           └─ wait for dataprovider

           │
           │ (meanwhile)
┌─────────────────────────────────┐
│ manager.start_plugin("train")    │
│ (if not already started)         │
└──────────┬──────────────────────┘
           │
           ▼ ray.get(.start.remote())
    TrainPlugin.on_start()
           │
           ├─ try to get initial values from orchestrator
           │
           └─ check_and_start_training() → still waiting


T=3: Background message processing loop
┌──────────────────────────────────────┐
│ manager.start_processing_loop()      │
│ (Background thread, interval=0.1s)   │
└──────────┬───────────────────────────┘
           │
     ┌─────┴─────────────────────────────┐
     │ Loop iteration every 0.1s          │
     │                                    │
     │ for each plugin_wrapper:           │
     │   ray.get(                         │
     │     wrapper.process_messages       │
     │     .remote(max_messages=10)       │
     │   )                                │
     │                                    │
     └────────────────────────────────────┘
              │ (continuous)
              │ Polls ray.util.queue.Queue for:
              │ 1. Pub/Sub messages
              │ 2. Environment updates
              │
              ▼ Messages delivered immediately


T=4: SetupPlugin publishes dataprovider
┌────────────────────────────────────┐
│ SetupPlugin.on_start() continued:   │
│                                     │
│ self.set_env_variable(             │
│   "dataprovider", dataprovider     │
│ )                                  │
└──────────┬────────────────────────┘
           │
           ▼ ray.get(.set_env_variable.remote(...))
    PluginOrchestrator receives
    _env_subscriptions["dataprovider"] = ["train-plugin"]
           │
           ▼ ray.get(PluginHandler[train].receive_env_update.remote(...))
        receive_env_update(EnvUpdate(key="dataprovider", value=dp))
           │
           ├─ self._local_env["dataprovider"] = dp
           │
           └─ call on_dataprovider_changed(update)
                     │
                     ▼ TrainPlugin.on_dataprovider_changed()
                        self.dataprovider = update.value
                        check_and_start_training()
                           │
                           ├─ model = ✓
                           ├─ dataprovider = ✓
                           │
                           └─► run_training()
                                  │
                                  ▼ Training loop starts!
```

---

## Data Flow: Service Invocation

```
┌──────────────────┐
│ PluginA          │
│                  │
│ invoke_service(  │
│   "plugin-b",    │
│   "compute",     │
│   x=5            │
│ )                │
└────────┬─────────┘
         │
         │ self._orchestrator = PluginOrchestrator handle
         │
         ▼ import ray
         ray.get(
           self._orchestrator.invoke_service.remote(
             "plugin-b",
             "compute",
             (5,),      # args as tuple
             {}         # kwargs
           )
         )
         │
         │ BLOCKING CALL - waits for response
         │
         ▼ PluginOrchestrator.invoke_service()
         
         if plugin_id not in self._plugins:
            raise ValueError()
         
         handle = self._plugins["plugin-b"]
         
         ray.get(
           handle.execute_service.remote(
             "compute",
             5
           )
         )
         │
         ▼ PluginHandler[plugin-b].execute_service()
         
         if "compute" not in self.plugin.get_services():
            raise ValueError()
         
         method = getattr(self.plugin, "compute")
         return method(5)  # Returns immediately
         │
         ▼ PluginB.compute(5)
         return 5 * 2  # Result = 10
         │
         │ Result returned through ray.get() chain
         │
         ▼ Back to PluginA

result = 10  # Unblocks


IMPORTANT: This is SYNCHRONOUS
- If compute() takes 5 seconds, invoke_service() blocks for 5 seconds
- Can cause deadlocks if not careful with circular dependencies
- Use pub/sub for async work
```

---

## Data Flow: ObjectRef (Large Data)

```
Publisher (e.g., PluginA):
┌────────────────────────────────────┐
│ tensor = torch.randn(10000, 10000) │ ← Huge tensor
│                                    │
│ # Option 1: Direct publish         │
│ self.publish("data", tensor)       │
│ → Will serialize through Ray       │
│ → SLOW for large objects           │
│                                    │
│ # Option 2: Zero-copy publish      │
│ self.publish_object_ref(           │
│   "data", tensor                   │
│ )                                  │
└────────┬─────────────────────────┘
         │
         ▼ plugin_base.py:192-198
         data_ref = ray.put(tensor)
         │
         ├─ Serializes tensor once
         ├─ Stores in Ray object store
         ├─ Returns ObjectRef (small handle)
         │
         ▼ return ray.get(self._orchestrator.publish.remote(
             "data",
             {"data_ref": data_ref}   ← Send only the handle!
           ))
         │
         ▼ PluginOrchestrator.publish()
         │
         │ for each subscriber queue:
         │   q.put({"data_ref": data_ref})  ← Efficient!
         │
         ▼ Message size: ~20 bytes (instead of TB)


Subscriber (e.g., PluginB):
┌────────────────────────────────────┐
│ PluginHandler[B].process_messages()│
└────────┬─────────────────────────┘
         │
         ▼ while not q.empty():
         msg = q.get(block=False)
         
         if isinstance(msg, dict) and "data_ref" in msg:
             data = ray.get(msg["data_ref"])  ← Fetch from object store
         else:
             data = msg
         
         # Call plugin callback
         callback(data, env)


Benefits:
✓ Tensor stored once in Ray's object store
✓ Multiple subscribers reference same object
✓ Network bandwidth: O(1) instead of O(num_subscribers)
✓ First ray.get() is fast; subsequent calls cache
```

---

## Message Processing Loop Architecture

```
┌──────────────────────────────────────────────────┐
│ PluginManager.start_processing_loop()            │
│                                                  │
│ Creates background daemon thread                │
│ (_processing_thread)                             │
└──────────┬───────────────────────────────────────┘
           │
           ▼ Thread starts: _process_loop(interval=0.1)
     
     ┌────────────────────────────────────────┐
     │ while not self._stop_event.is_set():   │
     │   # Runs continuously every 100ms      │
     │                                        │
     │   for plugin_id, wrapper in \          │
     │       self._plugin_wrappers.items():   │
     │                                        │
     │     try:                               │
     │       ray.get(                         │
     │         wrapper                        │
     │           .process_messages            │
     │           .remote(max_messages=10)     │
     │       )                                │
     │     except Exception as e:             │
     │       logger.error(...)                │
     │                                        │
     │   time.sleep(0.1)  # Interval          │
     │                                        │
     └────────────────────────────────────────┘
              │ (remote call on each wrapper)
              │
              ▼ PluginHandler.process_messages()
         
         max_messages = 10
         messages_processed = 0
         
         for sub in self._subscriptions:
           q = sub.get("queue")
           if not q: continue
           
           callback_name = sub["callback"]
           publish_to = sub["publish_to"]
           
           # Process up to 10 messages from this queue
           while not q.empty() and \
                 messages_processed < max_messages:
             
             msg = q.get(block=False)
             
             # Resolve ObjectRef if needed
             if isinstance(msg, dict) and "data_ref" in msg:
               data = ray.get(msg["data_ref"])
             else:
               data = msg
             
             # Call the callback
             if hasattr(self.plugin, callback_name):
               callback = getattr(self.plugin, callback_name)
               result = callback(data, self._local_env)
               
               # Re-publish if configured
               if result is not None and publish_to:
                 self.orchestrator.publish.remote(
                   publish_to, result
                 )
             
             messages_processed += 1
         
         return messages_processed


Key Points:
═══════════
• Runs in background thread (main thread remains responsive)
• Periodic polling of all plugin queues (0.1s)
• Non-blocking queue.get(block=False)
• Limits messages per poll (max_messages=10)
• Prevents thread starvation if one plugin floods
• Recursive ray.get() for ObjectRef resolution
• Republishing allows plugin chaining


Example Flow:
═════════════
T=0: publish("input", data1)
     → PluginA._subscriptions[0].queue ← data1
     
T=1: process_messages() poll
     → q.get() → data1
     → callback(data1) → returns data2
     → publish("output", data2)
        → PluginB._subscriptions[0].queue ← data2
     
T=2: process_messages() poll
     → PluginB: q.get() → data2
     → callback(data2) → returns data3
     → ...
```

---

## Ray Actor Communication Pattern

```
┌─────────────────────────────────────────┐
│ Main Process (PluginManager)            │
└────────────────────┬────────────────────┘
                     │ ray.init()
                     │
                     ▼ Ray Cluster Started
        
        ┌────────────────────────────┐
        │ Ray Cluster (1+ nodes)     │
        │                            │
        │ ┌──────────────────────┐   │
        │ │ PluginOrchestrator   │   │ Remote Actor
        │ │ (running in worker)  │   │
        │ └──┬───────────────┬───┘   │
        │    │               │       │
        │ ┌──▼──┐ ┌──────┐ ┌─▼───┐   │
        │ │ PH1 │ │ PH2  │ │ PH3 │   │ Remote Actors
        │ └─────┘ └──────┘ └─────┘   │
        │                            │
        └────────────────────────────┘
                     △
                     │ ray.get()
                     │ ray.put()
                     │ ray.remote()


Communication Pattern:
══════════════════════

1. Main thread calls: method.remote()
   └─ Returns ObjectRef immediately (doesn't wait)

2. Main thread calls: ray.get(ObjectRef)
   └─ BLOCKS waiting for result
   └─ Result is copied back to main process

3. Ray cluster executes method asynchronously
   └─ In separate worker process
   └─ Isolated from main process

4. Results stored in Ray's object store
   └─ Can be passed to other actors
   └─ ray.get() fetches from store

Example:
═══════

PluginManager (Main):               Ray Cluster:
┌────────────────────┐             ┌─────────────────┐
│ ref = handle       │ remote()    │ method running  │
│ .method.remote()   │────────────>│ in worker       │
│                    │             │                 │
│ result = ray.get() │ blocking    │                 │
│ (ref)              │<────────────│ result ready    │
│                    │   returns   │                 │
└────────────────────┘             └─────────────────┘


This is why:
✓ Plugins are isolated (separate processes)
✓ Failures in one plugin don't crash others
✓ Plugins can run on different machines
✓ ray.get() is blocking (must wait for result)
```

---

## Environment Variable Propagation

```
PluginA.set_env_variable("key", value)
         │
         ▼ ray.get(
             self._orchestrator.set_env_variable.remote("key", value)
           )
         
         PluginOrchestrator.set_env_variable():
         ┌──────────────────────────────────────┐
         │ old_value = self.env_manager.get()   │
         │ self.env_manager.set("key", value)   │
         │                                      │
         │ if "key" in self._env_subscriptions: │
         │   for plugin_id in subscribers:      │
         │     if plugin_id in self._plugins:   │
         │       handle = self._plugins[id]     │
         │       ray.get(                       │
         │         handle                       │
         │           .receive_env_update       │
         │           .remote(update)            │
         │       )                              │
         └──────────────────────────────────────┘
         
         PluginHandler.receive_env_update():
         ┌────────────────────────────────────┐
         │ self._local_env[key] = value        │
         │                                    │
         │ # Call env subscriptions            │
         │ for env_sub in subscriptions:       │
         │   if env_sub["name"] == "key":      │
         │     callback_name = env_sub["cb"]   │
         │     callback = getattr(             │
         │       self.plugin, callback_name    │
         │     )                               │
         │     callback(update)  ← Runs sync   │
         │                                    │
         └────────────────────────────────────┘
         
         Plugin receives update immediately
         Can start work based on value


Timeline:
═════════
T0: PluginA.set_env_variable("model", m)
T1: PluginOrchestrator broadcasts
T2: PluginB receives EnvUpdate
T3: PluginB.on_model_changed() called
T4: PluginB starts using model

Latency: ~1-2ms (network round-trip)
```

---

## Queue Evolution: From Multiprocessing to Ray

```
OLD SYSTEM (draft/plugin_pubsub_old.py):
═════════════════════════════════════════

import torch.multiprocessing as mp

class Topic:
    def __init__(self):
        self.subscribers: Dict[str, mp.Queue] = {}
    
    def publish(self, data):
        for queue in self.subscribers.values():
            queue.put_nowait(data)  # Non-blocking

Problem:
- Multiprocessing queues are slow
- Can't scale beyond single machine
- Tight coupling to mp.Manager()


NEW SYSTEM (plugin_manager.py):
═══════════════════════════════

from ray.util.queue import Queue

class PluginOrchestrator:
    def __init__(self):
        self._topics: Dict[str, List[Queue]] = {}
    
    def subscribe(self, topic: str) -> Queue:
        if topic not in self._topics:
            self._topics[topic] = []
        sub_queue = Queue(maxsize=100)
        self._topics[topic].append(sub_queue)
        return sub_queue
    
    def publish(self, topic: str, msg) -> int:
        if topic not in self._topics:
            return 0
        delivered = 0
        for q in self._topics[topic]:
            try:
                q.put(msg, block=False)
                delivered += 1
            except:
                pass  # Queue full
        return delivered

Benefits:
✓ Ray.util.queue is distributed (Ray-native)
✓ Can span multiple machines
✓ Scales to 1000s of publishers/subscribers
✓ Backpressure handling (queue full = drop message)
✓ Built for Ray ecosystem
```

---

## Known Python 3.14 + Ray Issue Timeline

```
Problem Discovery:
═════════════════
When: Running tests on Python 3.14
Ray 2.55.1 tries to start dashboard

Ray Dashboard Code:
  └─ pydantic v1 schema definition
  └─ Generates field: id = ...
  └─ pydantic.v1 fails to infer type
  └─ ConfigError: unable to infer type for attribute "id"

Cascade:
  └─ Dashboard fails to start
  └─ GCS (Ray state manager) waits for dashboard
  └─ Raylet times out after 30 seconds
  └─ Node registration fails
  └─ Ray.init() hangs then fails


Solution Path:
══════════════
Option 1: Disable dashboard
  os.environ["RAY_DISABLE_DASHBOARD"] = "1"
  ray.init(include_dashboard=False)
  ✓ Works: Dashboard doesn't start
  ✗ Problem: Still attempts in subprocesses

Option 2: Increase timeout
  os.environ["RAY_raylet_start_wait_time_s"] = "180"
  ✓ Works: More time to start
  ✗ Problem: Just delays the failure

Option 3: Disable all monitoring
  RAY_disable_memory_monitor = "1"
  RAY_disable_metrics_exporter = "1"
  RAY_metrics_export_period = "0"
  ✓ Helps: Reduces bloat

Option 4: Increase other timeouts
  RAY_gcs_server_request_timeout_seconds = "60"
  ✓ Defensive: Prevents cascading timeouts


Current Status (conftest.py):
═════════════════════════════
All options applied together:
  - Dashboard disabled
  - Memory monitor disabled
  - Metrics exporter disabled
  - All timeouts tripled
  
Result: Tests can sometimes run
But: Ray initialization is flaky on Python 3.14


Workarounds:
════════════
1. Upgrade to Ray 2.56+ (if available)
2. Use Python 3.13 or earlier
3. Use Ray local_mode=True (single-process, no distribution)
4. Use Ray initialization with custom node config
```

---

## Summary: Where Ray Is Used

```
┌─────────────────────────────────────────────────────────┐
│ ModularNet Plugin System - Ray Usage Map               │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ CORE RAY INTEGRATION:                                  │
│ ├─ @ray.remote decorator                              │
│ │  └─ PluginOrchestrator (actor)                      │
│ │  └─ PluginHandler (actor)                           │
│ │                                                     │
│ ├─ ray.init() / ray.is_initialized()                  │
│ │  └─ Initialize Ray cluster                          │
│ │  └─ Called in PluginManager.__init__()              │
│ │                                                     │
│ ├─ ray.get(ActorHandle.method.remote())               │
│ │  └─ Synchronous calls to actors                     │
│ │  └─ Blocks waiting for result                       │
│ │  └─ Used for EVERY plugin operation                 │
│ │                                                     │
│ ├─ ray.put(data)                                      │
│ │  └─ Zero-copy large data passing                    │
│ │  └─ Used in publish_object_ref()                    │
│ │                                                     │
│ └─ ray.util.queue.Queue                               │
│    └─ Distributed message queues                      │
│    └─ Pub/Sub topic implementation                    │
│                                                         │
│ SECONDARY INTEGRATION:                                 │
│ └─ torch.multiprocessing as mp                        │
│    └─ Used in ModularSpace only                       │
│    └─ For CUDA compatibility                          │
│                                                         │
│ ABSTRACTION LAYER:                                    │
│ ├─ BasePlugin (hides Ray from developers)            │
│ ├─ PluginDescriptor (metadata + serialization)       │
│ ├─ EnvironmentManager (shared state)                 │
│ └─ PluginManager (user-facing API)                   │
│                                                         │
└─────────────────────────────────────────────────────────┘
```
