"""
Example: Using both Ray and torch.multiprocessing backends interchangeably.

This demonstrates how to switch between backends by simply changing the import.
"""

# ==============================================================================
# Ray version (original)
# ==============================================================================
# from modularnet.plugin.plugin_manager import PluginManager
# manager = PluginManager(auto_start_ray=True)

# ==============================================================================
# torch.multiprocessing version (NEW)
# ==============================================================================
# from modularnet.plugin.plugin_manager_mp import PluginManager
# manager = PluginManager()

# ==============================================================================
# Example usage (identical API for both backends):
# ==============================================================================

from modularnet.plugin.plugin_manager_mp import PluginManager
from modularnet.plugin.plugin_descriptor import PluginDescriptor

# Create manager
manager = PluginManager()

# Define a plugin
descriptor = PluginDescriptor(
    name="example_plugin",
    package="myapp.plugins",
    class_name="ExamplePlugin",
    version="1.0.0"
)

# Load plugin
manager.load_plugin(descriptor, config={"param1": "value1"})

# Start plugin
manager.start_plugin("example_plugin")

# Use plugin services
result = manager.invoke_service("example_plugin", "process_data", "some_input")

# Publish to topic
manager.publish("topic_name", {"data": "some_message"})

# Set environment variable (broadcasts to all subscribers)
manager.set_env_variable("shared_param", 42)

# Get plugin status
status = manager.get_all_plugin_status()
print(f"All plugins: {status}")

# Start processing loop (handles async pub/sub)
manager.start_processing_loop(interval=0.1)

# ... do work ...

# Stop and cleanup
manager.stop_all_plugins()
manager.shutdown()


# ==============================================================================
# Key differences between Ray and torch.multiprocessing backends:
# ==============================================================================
"""
FEATURE                    RAY                          torch.multiprocessing
-------------------        -----                        ----------------------
Initialization             ray.init() required          No initialization
Infrastructure             GCS + raylets + scheduler    Just processes
Startup time               2-5 seconds                  <1 second
Memory per actor           ~50-100MB overhead           Minimal
Multi-machine support      Yes                          No (single machine only)
Pub/Sub efficiency         Optimized                    Basic queues
Debugging                  Distributed tracing          Standard Python debugging
Failure handling           Built-in recovery            Manual process restart
External dependencies      Many (protobuf, grpc, etc)   Just PyTorch (already a dep)

RECOMMENDED USE:
- Ray:    Multi-machine setups, built-in fault tolerance, high throughput
- torch.multiprocessing: Single machine, simpler setup, easier debugging
"""
