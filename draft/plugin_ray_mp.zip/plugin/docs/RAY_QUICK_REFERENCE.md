# ModularNet Ray Integration - Quick Reference

## 🎯 One-Minute Summary

**ModularNet uses Ray for plugin orchestration:**
- Each plugin runs in its own Ray actor (process isolation)
- Central PluginOrchestrator manages all plugins
- 3 communication patterns: pub/sub, environment variables, services
- Abstraction layer hides Ray complexity from plugin developers

---

## 📍 Ray Files & Import Locations

```
✓ DIRECTLY IMPORTS RAY (5 files):
  ├─ plugin_manager.py          (lines 22-23)      ← MAIN HUB
  ├─ plugin_handler.py          (line 18)          ← WORKER ACTORS
  ├─ plugin_base.py             (lines 173,192,212,231,258) ← LAZY IMPORTS
  ├─ deeplearning_train_plugin.py (lines 97-100)   ← LAZY IMPORTS
  └─ deeplearning_setup_plugin.py (not shown but uses orchestrator)

✓ MULTIPROCESSING (torch.multiprocessing):
  └─ modularspace.py            (line 14)          ← For CUDA compatibility
```

---

## 🏗️ Architecture Layers

```
┌─────────────────────────────────────────────────┐
│  User Code (pipeline, trial)                    │
└────────────────────┬────────────────────────────┘
                     │ calls
┌────────────────────v────────────────────────────┐
│  PluginManager (High-Level API)                 │
│  - load_plugin() / start_plugin()               │
│  - publish() / set_env_variable()               │
│  - invoke_service() / start_processing_loop()   │
└────────────────────┬────────────────────────────┘
                     │ uses (ray.get/ray.remote)
┌────────────────────v────────────────────────────┐
│  PluginOrchestrator @ray.remote (Central Actor) │
│  ├─ Plugin registry                             │
│  ├─ Pub/Sub topic routing (ray.util.queue)      │
│  ├─ Environment variable broadcasts             │
│  └─ Service request dispatch                    │
└──┬──────────────────┬──────────────────┬────────┘
   │                  │                  │
   │ wraps            │                  │
┌──v──┐          ┌──v──┐          ┌──v──┐
│ PH1 │          │ PH2 │          │ PHN │  ← PluginHandler @ray.remote
│(Ray)│          │(Ray)│          │(Ray)│     (Worker Actors)
└──┬──┘          └──┬──┘          └──┬──┘
   │                │                │
┌──v──┐          ┌──v──┐          ┌──v──┐
│ P1  │          │ P2  │          │ PN  │  ← BasePlugin (User Plugin)
│(Py) │          │(Py) │          │(Py) │     (Runs in actor context)
└─────┘          └─────┘          └─────┘
```

---

## 🔌 Three Communication Patterns

### 1️⃣ Pub/Sub (Event-Driven)

```python
# In any plugin:
self.publish("data_ready", tensor)     # Send to all subscribers

# Declare subscriptions:
def get_subscriptions(self):
    return [
        Subscription(
            name="data_ready",
            callback="on_data_received",
            publish_to="results"  # Re-publish transformed data
        )
    ]

def on_data_received(self, data, env):
    return transform(data)  # Will be published to "results"
```

**How it works:**
1. PluginOrchestrator maintains `_topics: Dict[str, List[Queue]]`
2. Each queue is `ray.util.queue.Queue` (distributed)
3. Main thread polls with `process_messages.remote()` (0.1s interval)
4. Large data: Use `publish_object_ref()` + `ray.put()`

### 2️⃣ Environment Variables (Shared State)

```python
# Set (broadcast to all subscribers)
self.set_env_variable("model", trained_model)

# Subscribe to changes
def get_env_subscriptions(self):
    return [Subscription(name="model", callback="on_model_changed")]

def on_model_changed(self, update: EnvUpdate):
    print(f"Got {update.key}={update.value}, was {update.old_value}")
    self.model = update.value
```

**How it works:**
1. EnvironmentManager stores `_env: Dict[str, Any]`
2. Subscribed plugins receive `EnvUpdate` via `receive_env_update.remote()`
3. Thread-safe with locks
4. Used in deeplearning workflow (setup → train)

### 3️⃣ Services (Sync RPC)

```python
# Declare service
def get_services(self):
    return ["compute"]

def compute(self, x):
    return x * 2

# Call from another plugin
result = self.invoke_service("other_plugin", "compute", 5)  # Returns 10
```

**How it works:**
1. Service call goes through orchestrator
2. `ray.get(handle.execute_service.remote(method, args))` - BLOCKS
3. Returns method result directly
4. Exceptions propagated to caller

---

## 📊 Ray Methods Used

| Method | Purpose | Location |
|--------|---------|----------|
| `ray.init()` | Initialize Ray cluster | plugin_manager.py:286 |
| `ray.is_initialized()` | Check cluster status | plugin_manager.py:278 |
| `@ray.remote` | Mark class/function as actor/task | plugin_manager.py:32, plugin_handler.py:26 |
| `ActorHandle.method.remote()` | Call actor method asynchronously | Throughout |
| `ray.get(ObjectRef)` | Wait for remote result | Throughout |
| `ray.put(data)` | Put data in object store (zero-copy) | plugin_base.py:193, plugin_manager.py:466 |
| `ray.util.queue.Queue` | Distributed queue | plugin_manager.py:23 |

---

## 🔄 Plugin Lifecycle

```
1. DESCRIPTOR
   PluginDescriptor(name, package, class_name, version, options)

2. LOAD
   manager.load_plugin(descriptor, config)
   └─ PluginHandler.load_plugin() [ray.get(...remote())]
   └─ Dynamic import + instantiate plugin

3. START
   manager.start_plugin(plugin_id)
   └─ plugin.on_start()
   └─ Register subscriptions with orchestrator

4. RUN
   manager.start_processing_loop()
   └─ Background thread: process_messages.remote() every 0.1s
   └─ Messages delivered via callbacks

5. STOP
   manager.stop_plugin(plugin_id)
   └─ plugin.on_stop()

6. UNLOAD
   manager.unload_plugin(plugin_id)
   └─ Cleanup
```

---

## 🚀 Currently Active Plugins

| Plugin | Base Class | Purpose | Status |
|--------|-----------|---------|--------|
| DeeplearningSetupPlugin | BasePlugin | Create model + dataprovider | ✓ Active |
| DeeplearningTrainPlugin | BasePlugin | Train model | ✓ Active |
| ModularClusterPlugin | Plugin (old) | K-means clustering | Pub/Sub example |
| ModularObserverPlugin | Plugin (old) | Watch layers | ✓ Active |

---

## ⚠️ Known Issues

### Python 3.14 + Ray 2.55.1
- **Problem**: Dashboard won't start (pydantic v1 issue)
- **Symptom**: Raylet timeout after 30s
- **Fix**: Set in [conftest.py](modularnet/plugin/tests/conftest.py)
  ```python
  os.environ["RAY_DISABLE_DASHBOARD"] = "1"
  os.environ["RAY_raylet_start_wait_time_s"] = "180"
  ```

### Pickling Issues (Resolved)
- **Problem**: Logger/PluginBase not serializable
- **Fix**: Added `__getstate__/__setstate__()` methods
- **See**: [pickle_fix.md](/memories/repo/pickle_fix.md)

---

## 📝 Example: Complete Plugin

```python
from modularnet.plugin import BasePlugin, Subscription, PluginDescriptor

class MyPluginDescriptor(PluginDescriptor):
    def __init__(self):
        super().__init__(
            name="my-plugin",
            package="mypackage.my_plugin",
            class_name="MyPlugin",
            version="1.0"
        )

class MyPlugin(BasePlugin):
    def on_start(self):
        print(f"Plugin {self.plugin_id} started")
        
    def on_stop(self):
        print("Stopping")
    
    # Pub/Sub subscription
    def get_subscriptions(self):
        return [
            Subscription(
                name="input_data",
                callback="process_data"
            )
        ]
    
    def process_data(self, data, env):
        print(f"Received: {data}")
        return {"processed": data}
    
    # Env var subscription
    def get_env_subscriptions(self):
        return [
            Subscription(
                name="config",
                callback="on_config_change"
            )
        ]
    
    def on_config_change(self, update):
        print(f"Config updated: {update.value}")
    
    # RPC service
    def get_services(self):
        return ["echo"]
    
    def echo(self, text):
        return f"Echo: {text}"

# Usage:
# manager.load_plugin(MyPluginDescriptor())
# manager.start_plugin("my-plugin")
# manager.publish("input_data", "hello")
# manager.invoke_service("my-plugin", "echo", "test")
```

---

## 🔍 Where to Look for Specific Tasks

| Task | File | Line |
|------|------|------|
| Ray initialization | plugin_manager.py | 278-291 |
| Plugin orchestration | plugin_manager.py | 32-258 |
| Plugin wrapping | plugin_handler.py | 26-321 |
| Plugin interface | plugin_base.py | 1-287 |
| Pub/Sub publishing | plugin_base.py | 166-200 |
| Env variable get/set | plugin_base.py | 204-249 |
| Service invocation | plugin_base.py | 251-287 |
| Message processing | plugin_handler.py | 256-305 |
| Processing loop | plugin_manager.py | 540-586 |

---

## 💡 Best Practices

✅ **DO:**
- Use `publish_object_ref()` for tensors/arrays >1MB
- Subscribe to environment variables for shared state
- Use services for sync communication
- Inherit from BasePlugin (not Plugin)
- Return values from pub/sub callbacks (they get republished if configured)

❌ **DON'T:**
- Import ray directly in plugin code (it's abstracted)
- Use `ray.get()` inside plugin callbacks (causes recursion)
- Store unpicklable objects (threads, locks, file handles)
- Assume deterministic message ordering in pub/sub
- Block indefinitely in plugin methods

---

## 🔗 Key Abstractions

| Abstraction | What's Hidden | Interface |
|-------------|---------------|-----------|
| BasePlugin | Ray actors, queues, broadcasts | Simple methods: publish(), invoke_service() |
| PluginManager | PluginOrchestrator, ray.get/ray.remote | High-level load/start/stop, message loop |
| Subscriptions | Queue management, callback dispatch | Declarative list in get_subscriptions() |
| Environment | Distributed state, notifications | Simple dict-like interface |

This design allows **plugin developers to ignore Ray entirely** while benefiting from its distribution model.
