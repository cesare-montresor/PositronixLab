# ModularNet Codebase Exploration: Ray & Multiprocessing Integration

## Executive Summary

ModularNet uses **Ray as the primary distributed computing framework** for its plugin system, with **torch.multiprocessing as a secondary system** for the ModularSpace component. The architecture is well-designed with a sophisticated abstraction layer that isolates plugins in Ray actors and manages inter-plugin communication through pub/sub, environment variables, and services.

---

## 1. Ray Integration Overview

### 1.1 High-Level Architecture

The Ray integration is centered on the **Plugin System** (`modularnet/plugin/`):

```
┌─────────────────────────────────────────────────────────┐
│  PluginManager (High-Level User Interface)              │
│  - load_plugin() / start_plugin() / stop_plugin()       │
│  - publish() / set_env_variable() / invoke_service()    │
└──────────────────────┬──────────────────────────────────┘
                       │
┌──────────────────────v──────────────────────────────────┐
│  PluginOrchestrator (@ray.remote - Ray Actor)          │
│  - Central orchestration hub                            │
│  - Pub/sub topic routing                                │
│  - Environment variable management                      │
│  - Service request/response dispatch                    │
└────────────────────────────────────────────────────────┘
         │                │                │
    ┌────v─────┐   ┌─────v──────┐   ┌────v─────┐
    │ Handler 1 │   │  Handler 2 │   │ Handler N │
    │ (Ray)    │   │   (Ray)    │   │  (Ray)   │
    └────┬─────┘   └─────┬──────┘   └────┬─────┘
         │                │               │
    ┌────v─────┐   ┌─────v──────┐   ┌────v─────┐
    │ Plugin 1  │   │  Plugin 2  │   │ Plugin N  │
    │ (Python)  │   │ (Python)   │   │ (Python) │
    └──────────┘   └────────────┘   └──────────┘
```

### 1.2 Ray Components Used

| Component | Location | Purpose |
|-----------|----------|---------|
| `@ray.remote` | [plugin_manager.py:32](modularnet/plugin/plugin_manager.py#L32) | Marks `PluginOrchestrator` class as Ray actor |
| `@ray.remote` | [plugin_handler.py:26](modularnet/plugin/plugin_handler.py#L26) | Marks `PluginHandler` class as Ray actor |
| `ray.init()` | [plugin_manager.py:286](modularnet/plugin/plugin_manager.py#L286) | Initialize Ray cluster |
| `ray.get()` | Throughout plugin system | Synchronize on remote calls |
| `ray.put()` | [plugin_base.py:193](modularnet/plugin/plugin_base.py#L193) | Zero-copy data passing for large objects |
| `ray.remote()` | [plugin_handler.py:128](modularnet/plugin/plugin_handler.py#L128) | Create remote task references |
| `ray.util.queue.Queue` | [plugin_manager.py:23](modularnet/plugin/plugin_manager.py#L23) | Distributed queue for pub/sub |

### 1.3 Ray Configuration

**File:** [plugin_manager.py:278-291](modularnet/plugin/plugin_manager.py#L278-L291)

```python
ray.init(
    ignore_reinit_error=True,
    include_dashboard=False  # Disabled due to Python 3.14 pydantic issues
)
```

**Environment Setup:** [conftest.py](modularnet/plugin/tests/conftest.py)
- `RAY_DISABLE_DASHBOARD=1` - Prevents dashboard startup (pydantic v1 issues on Python 3.14)
- `RAY_raylet_start_wait_time_s=180` - Increased timeout for slow startup
- Additional memory monitor and metrics exporter disabled

---

## 2. All Files with Direct Ray Usage

### Files Directly Importing Ray:

1. **[plugin_manager.py](modularnet/plugin/plugin_manager.py)** (MAIN HUB)
   - Lines: 22-23 (import), 32 (PluginOrchestrator @ray.remote)
   - Ray usage: ray.init(), ray.get(), ray.put(), PluginOrchestrator remote calls
   - **Impact**: This is the core Ray integration point

2. **[plugin_handler.py](modularnet/plugin/plugin_handler.py)** (WORKER)
   - Lines: 18 (import), 26 (@ray.remote PluginHandler)
   - Ray usage: ray.get() for ObjectRef resolution, plugin communication
   - **Impact**: Each plugin runs in this Ray actor

3. **[plugin_base.py](modularnet/plugin/plugin_base.py)** (PLUGIN INTERFACE)
   - Lines: 173, 192, 212, 231, 258 (lazy imports within methods)
   - Ray usage: ray.get(), ray.put() for inter-plugin communication
   - **Pattern**: Ray imported inside methods only when orchestrator is available

4. **[deeplearning_train_plugin.py](modularnet/deeplearning/deeplearning_train_plugin.py)**
   - Lines: 97-100 (lazy import, ray.get())
   - Ray usage: Get model/dataprovider/space from environment
   - **Extends**: BasePlugin, uses orchestrator communication

### Indirectly Ray-Aware Files:

5. **[deeplearning_setup_plugin.py](modularnet/deeplearning/deeplearning_setup_plugin.py)**
   - Sets up environment variables via orchestrator
   - Does NOT directly import ray, but uses inherited methods

6. **[modularcluster_plugin.py](modularnet/modularcluster/modularcluster_plugin.py)**
   - Example pub/sub plugin
   - Inherits from `Plugin` class (old plugin system)
   - **Note**: Uses different base class than new BasePlugin

---

## 3. Plugin System Architecture

### 3.1 Core Classes and Responsibilities

| Class | File | Responsibility |
|-------|------|-----------------|
| `PluginManager` | [plugin_manager.py](modularnet/plugin/plugin_manager.py) | User-facing high-level API |
| `PluginOrchestrator` | [plugin_manager.py:32](modularnet/plugin/plugin_manager.py#L32) | Central Ray actor managing all plugins |
| `PluginHandler` | [plugin_handler.py](modularnet/plugin/plugin_handler.py) | Ray actor wrapping individual plugins |
| `BasePlugin` | [plugin_base.py](modularnet/plugin/plugin_base.py) | Abstract base for all plugins |
| `PluginDescriptor` | [plugin_descriptor.py](modularnet/plugin/plugin_descriptor.py) | Serializable metadata for dynamic loading |
| `EnvironmentManager` | [environment_manager.py](modularnet/plugin/environment_manager.py) | Thread-safe shared state |

### 3.2 Plugin Lifecycle

```
1. DESCRIPTOR
   └─> PluginDescriptor (metadata: package, class, name, version, options)

2. LOAD
   PluginManager.load_plugin(descriptor, config)
   └─> PluginHandler.load_plugin() via ray.get(wrapper.load_plugin.remote())
       └─> Dynamically import and instantiate plugin class

3. START
   PluginManager.start_plugin(plugin_id)
   └─> PluginHandler.start() via ray.get(wrapper.start.remote())
       └─> Call plugin.on_start()
       └─> Register subscriptions with orchestrator

4. RUN
   PluginManager.start_processing_loop(interval=0.1)
   └─> Background thread calls wrapper.process_messages.remote()
       └─> Messages delivered via callbacks

5. STOP
   PluginManager.stop_plugin(plugin_id)
   └─> Call plugin.on_stop()
   └─> Unregister all subscriptions

6. UNLOAD
   PluginManager.unload_plugin(plugin_id)
   └─> Cleanup
```

### 3.3 Inter-Plugin Communication Mechanisms

#### Mechanism 1: Pub/Sub Topics (Event-Driven)

```python
# Publisher
self.publish(topic="data_ready", data=tensor)

# Subscriber
class MyPlugin(BasePlugin):
    def get_subscriptions(self):
        return [Subscription(
            name="data_ready",
            callback="on_data_received",
            publish_to="results"  # optional: republish results
        )]
    
    def on_data_received(self, data, env):
        return transform(data)  # republished to "results"
```

**Implementation:**
- Pub/Sub queues managed by PluginOrchestrator
- [ray.util.queue.Queue](modularnet/plugin/plugin_manager.py#L23) for distributed queues
- Large data: Use [ray.put()](modularnet/plugin/plugin_base.py#L193) for zero-copy
- Processing: Main thread polls via [process_messages()](modularnet/plugin/plugin_handler.py#L256)

#### Mechanism 2: Environment Variables (Shared State)

```python
# Setter
self.set_env_variable("model", trained_model)

# Subscriber/Watcher
class MyPlugin(BasePlugin):
    def get_env_subscriptions(self):
        return [Subscription(
            name="model",
            callback="on_model_changed"
        )]
    
    def on_model_changed(self, update: EnvUpdate):
        self.model = update.value
```

**Implementation:**
- Managed by EnvironmentManager in PluginOrchestrator
- Thread-safe (with locks)
- Changes broadcast to subscribed plugins via [receive_env_update()](modularnet/plugin/plugin_handler.py#L215)

#### Mechanism 3: Services (Sync Request/Response)

```python
# Service provider
class MyPlugin(BasePlugin):
    def get_services(self):
        return ["compute"]
    
    def compute(self, x):
        return x * 2

# Service consumer
result = self.invoke_service("plugin_id", "compute", 5)  # returns 10
```

**Implementation:**
- Synchronous RPC via [invoke_service()](modularnet/plugin/plugin_manager.py#L512)
- [ray.get()](modularnet/plugin/plugin_manager.py#L513) blocks until response

---

## 4. Multiprocessing Integration

### 4.1 torch.multiprocessing Usage

**Primary Location:** [modularspace.py:14](modularnet/modularspace/modularspace.py#L14)

```python
import torch.multiprocessing as mp

# Set spawn method for CUDA compatibility
try:
    mp.set_start_method('spawn', force=True)
except RuntimeError:
    pass  # Already set
```

**Purpose:** ModularSpace uses multiprocessing for:
- Background worker threads (actually Queue-based threading)
- GPU-compatible process spawning

### 4.2 Queue Systems

| Queue Type | Location | Purpose |
|-----------|----------|---------|
| `Queue()` | [modularspace.py:40](modularnet/modularspace/modularspace.py#L40) | Activation data queue |
| `Queue()` | [modularspace.py:47](modularnet/modularspace/modularspace.py#L47) | Batch queue |
| `Queue()` | [modularspace.py:54](modularnet/modularspace/modularspace.py#L54) | Loss tracking queue |
| `ray.util.queue.Queue` | [plugin_manager.py:23](modularnet/plugin/plugin_manager.py#L23) | Pub/sub topics |

### 4.3 Threading vs Multiprocessing

**File:** [logger.py:1-30](modularnet/logger/logger.py#L1-L30)

The Logger class:
- Thread-safe (uses `threading.Lock()`)
- Process-safe (implements `__getstate__/__setstate__` for pickling)
- NOT multiprocessing-based, despite the import

**Known Issue:** [pickle_fix.md](/memories/repo/pickle_fix.md)
- Logger and PluginBase were not picklable initially
- Solution: Added `__getstate__()/__setstate__()` methods
- Fork method works with debuggers; spawn method required for CUDA

---

## 5. Abstraction Layer Analysis

### 5.1 Is There An Abstraction Layer?

**YES** - The plugin system provides a clean abstraction:

**Level 1: Orchestrator Abstraction (Ray implementation detail hidden)**
- User calls: `plugin_manager.publish()`, `plugin_manager.invoke_service()`
- Implementation: Ray.get/Ray.remote calls wrapped invisibly

**Level 2: Plugin Interface Abstraction (BasePlugin)**
- Plugins inherit from `BasePlugin`
- Use simple methods: `self.publish()`, `self.invoke_service()`, `self.set_env_variable()`
- Ray complexity invisible to plugin developers

**Level 3: Descriptor Pattern (Dynamic Loading)**
- `PluginDescriptor` allows runtime plugin discovery and loading
- Decouples plugin code from discovery mechanism

### 5.2 Abstraction Benefits

1. **Ray Details Hidden**: Plugin code doesn't import Ray directly
2. **Swappable Backend**: Could theoretically replace Ray with async/await or multiprocessing
3. **Backward Compatibility**: Old Plugin class still works (see modularcluster_plugin.py)
4. **Type Safety**: Descriptors provide metadata and validation

### 5.3 Abstraction Limitations

1. **Ray-Specific Features Not Exposed**: No direct access to Ray features (tasks, actors, remote objects)
2. **Performance**: Blocking `ray.get()` calls prevent async plugin coordination
3. **Serialization**: All plugin data must be pickle-able for Ray transmission

---

## 6. Current Plugin Implementations

### 6.1 Active Plugins

1. **DeeplearningSetupPlugin** ([deeplearning_setup_plugin.py](modularnet/deeplearning/deeplearning_setup_plugin.py))
   - Sets up model and dataprovider
   - Stores in environment variables

2. **DeeplearningTrainPlugin** ([deeplearning_train_plugin.py](modularnet/deeplearning/deeplearning_train_plugin.py))
   - Waits for model/dataprovider in environment
   - Runs training loop
   - Uses environment subscriptions to trigger on setup

3. **PluginModularCluster** ([modularcluster_plugin.py](modularnet/modularcluster/modularcluster_plugin.py))
   - Example pub/sub plugin
   - Subscribes to "cu_positions" topic
   - Publishes to "cu_labels" topic
   - **Note**: Uses old `Plugin` class, not new `BasePlugin`

4. **ModularObserverPlugin** ([modularobserver_plugin.py](modularnet/modularobserver/modularobserver_plugin.py))
   - Gets model from environment
   - Watches neural network layers

### 6.2 Example Inter-Plugin Workflow

```
1. User calls: manager.load_plugin(setup_descriptor)
2. User calls: manager.start_plugin("deeplearning-setup")
3. SetupPlugin.on_start() 
   └─> Creates model, dataset
   └─> self.set_env_variable("model", model)
   └─> self.set_env_variable("dataprovider", dataset)
4. TrainPlugin subscribed to env changes
   └─> Receives EnvUpdate for "model"
   └─> Receives EnvUpdate for "dataprovider"
   └─> on_model_changed() and on_dataprovider_changed() called
   └─> check_and_start_training() proceeds when both available
5. TrainPlugin.run_training()
   └─> Uses model and dataprovider from environment
```

---

## 7. Known Issues & Configuration

### 7.1 Python 3.14 Compatibility Issue

**Problem:** [ray_python314_issue.md](/memories/repo/ray_python314_issue.md)
- Ray 2.55.1 dashboard fails on Python 3.14 (pydantic v1 incompatibility)
- Raylet times out waiting for node registration (30s default)

**Solution Applied:**
- Disable dashboard: `include_dashboard=False` in ray.init()
- Environment variables in conftest.py
- Increase timeout: `RAY_raylet_start_wait_time_s=180`

**Status:** Tests cannot run; feature code is complete

### 7.2 Multiprocessing/Pickling Issue

**Problem:** [pickle_fix.md](/memories/repo/pickle_fix.md)
- Logger and PluginBase not picklable for multiprocessing
- Caused: `TypeError: cannot pickle '_thread.RLock' object`

**Solution Applied:**
- Added `__getstate__()/__setstate__()` methods
- Fork method for debugging; spawn for CUDA compatibility
- Set method at module load time in pipeline

---

## 8. File Structure Summary

### Core Plugin System
```
modularnet/plugin/
├── __init__.py                 # Exports: PluginManager, BasePlugin, etc.
├── plugin_manager.py           # PluginManager (high-level) + PluginOrchestrator (Ray)
├── plugin_handler.py           # PluginHandler (Ray actor for individual plugins)
├── plugin_base.py              # BasePlugin (abstract base)
├── plugin_descriptor.py        # PluginDescriptor (metadata)
├── environment_manager.py      # EnvironmentManager (shared state)
└── tests/
    ├── test_plugin_system.py   # Comprehensive tests
    ├── conftest.py             # Ray configuration
    └── README_TESTS.md         # Test documentation
```

### Plugin Implementations
```
modularnet/deeplearning/
├── deeplearning_setup_plugin.py      # BasePlugin: Sets up model/data
├── deeplearning_train_plugin.py      # BasePlugin: Runs training
└── deeplearning_common.py            # Training logic

modularnet/modularcluster/
└── modularcluster_plugin.py          # Old Plugin class: Clustering

modularnet/modularobserver/
└── modularobserver_plugin.py         # Old Plugin class: Observing
```

### Supporting Components
```
modularnet/logger/
├── logger.py                   # Thread-safe, picklable logger

modularnet/modularspace/
├── modularspace.py             # Uses torch.multiprocessing
└── modularspace_deeplearning.py # Space loss computation
```

---

## 9. Ray Calls Summary

### All ray.get() Calls (Synchronous Wait)
- [plugin_manager.py:220](modularnet/plugin/plugin_manager.py#L220) - Execute service
- [plugin_manager.py:231](modularnet/plugin/plugin_manager.py#L231) - Get plugin status
- [plugin_manager.py:238](modularnet/plugin/plugin_manager.py#L238) - Get all status
- [plugin_manager.py:252](modularnet/plugin/plugin_manager.py#L252) - Get errors
- [plugin_manager.py:322](modularnet/plugin/plugin_manager.py#L322) - Register plugin
- [plugin_manager.py:325](modularnet/plugin/plugin_manager.py#L325) - Load plugin
- [plugin_manager.py:333](modularnet/plugin/plugin_manager.py#L333) - Unregister plugin
- [plugin_manager.py:385](modularnet/plugin/plugin_manager.py#L385) - Start plugin
- [plugin_manager.py:408](modularnet/plugin/plugin_manager.py#L408) - Stop plugin
- [plugin_manager.py:432](modularnet/plugin/plugin_manager.py#L432) - Update config
- [plugin_manager.py:453](modularnet/plugin/plugin_manager.py#L453) - Publish
- [plugin_manager.py:467](modularnet/plugin/plugin_manager.py#L467) - Publish ObjectRef
- [plugin_manager.py:482](modularnet/plugin/plugin_manager.py#L482) - Set env variable
- [plugin_manager.py:486](modularnet/plugin/plugin_manager.py#L486) - Get env variable
- [plugin_manager.py:490](modularnet/plugin/plugin_manager.py#L490) - Get all env
- [plugin_manager.py:513](modularnet/plugin/plugin_manager.py#L513) - Invoke service
- [plugin_manager.py:524](modularnet/plugin/plugin_manager.py#L524) - Get status
- [plugin_base.py:174](modularnet/plugin/plugin_base.py#L174) - Publish (within plugin)
- [plugin_base.py:194](modularnet/plugin/plugin_base.py#L194) - Publish ObjectRef (within plugin)
- [plugin_base.py:213](modularnet/plugin/plugin_base.py#L213) - Set env variable (within plugin)
- [plugin_base.py:232](modularnet/plugin/plugin_base.py#L232) - Get env variable (within plugin)
- [plugin_base.py:259](modularnet/plugin/plugin_base.py#L259) - Invoke service (within plugin)
- [deeplearning_train_plugin.py:98-100](modularnet/deeplearning/deeplearning_train_plugin.py#L98-L100) - Get environment variables
- [plugin_handler.py:128](modularnet/plugin/plugin_handler.py#L128) - Subscribe to topic
- [plugin_handler.py:285](modularnet/plugin/plugin_handler.py#L285) - Resolve ObjectRef

### All ray.put() Calls (Zero-Copy Serialization)
- [plugin_manager.py:466](modularnet/plugin/plugin_manager.py#L466) - Publish large data
- [plugin_base.py:193](modularnet/plugin/plugin_base.py#L193) - Publish object reference

### All ray.remote() Calls (Create Remote Reference)
- [plugin_handler.py:128](modularnet/plugin/plugin_handler.py#L128) - Subscribe to topic

### All @ray.remote Decorators (Mark as Ray Actor/Task)
- [plugin_manager.py:32](modularnet/plugin/plugin_manager.py#L32) - PluginOrchestrator actor
- [plugin_handler.py:26](modularnet/plugin/plugin_handler.py#L26) - PluginHandler actor

---

## 10. Diagram: Data Flow Example

```
PluginManager (Main Thread)
    │
    ├─ load_plugin(setup_descriptor)
    │   └─ ray.get(PluginOrchestrator.register_plugin.remote(id, PluginHandler))
    │   └─ ray.get(PluginHandler.load_plugin.remote(descriptor, config))
    │
    ├─ start_plugin("setup")
    │   └─ ray.get(PluginHandler.start.remote())
    │       └─ plugin.on_start()
    │           ├─ model = MetaModel(...)
    │           ├─ data = DataProvider(...)
    │           └─ self.set_env_variable("model", model)
    │               └─ ray.get(PluginOrchestrator.set_env_variable.remote("model", model))
    │                   └─ PluginOrchestrator broadcasts to all subscribed plugins
    │
    ├─ start_processing_loop()
    │   └─ Background thread calls ray.get(PluginHandler.process_messages.remote())
    │       └─ DeliverMessages from queues to callbacks
    │
    └─ TrainPlugin receives env update
        └─ ray.get(PluginHandler.receive_env_update.remote(EnvUpdate))
            └─ on_model_changed(EnvUpdate)
                └─ check_and_start_training()
                    └─ run_training() uses model from environment
```

---

## 11. Recommendations

### For Extension:
1. **New plugins**: Inherit from `BasePlugin`, implement abstract methods
2. **Large data**: Use `publish_object_ref()` instead of `publish()`
3. **Synchronization**: Use environment variables instead of shared state

### For Debugging:
1. Enable logging: Set logger level to DEBUG
2. Check ray.get() calls for errors (they block the main thread)
3. Verify plugin subscriptions are registered in orchestrator

### For Performance:
1. Batch message processing in `process_messages()`
2. Use Ray's object reference serialization for >1MB data
3. Consider async plugins in future (would require Ray async API)

---

## Conclusion

ModularNet has a **well-architected Ray-based plugin system** that provides:
- ✅ Clean abstraction over Ray complexity
- ✅ Three communication patterns: pub/sub, env vars, services
- ✅ Dynamic plugin loading and lifecycle management
- ✅ Distributed execution with proper isolation

The system is **production-ready** for single-machine plugins. For multi-machine clusters, additional Ray configuration would be needed (address, num_cpus, GPUs, etc.).
