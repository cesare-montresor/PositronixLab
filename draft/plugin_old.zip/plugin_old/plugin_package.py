

from typing import Any, Dict, List, Union, Optional, Type
from dataclasses import dataclass, field
import json
import importlib
from pathlib import Path


def _import_class(class_path: str) -> Any:
    """Import a class from module path string (e.g., 'module.submodule.ClassName')."""
    parts = class_path.rsplit('.', 1)
    if len(parts) == 1:
        raise ValueError(f"Invalid class path: {class_path}")
    module_path, class_name = parts
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def _get_class_path(cls: Any) -> str:
    """Get full module path of a class."""
    return f"{cls.__module__}.{cls.__qualname__}"


@dataclass
class PluginDescriptor:
    """
    Represents an instance of a plugin with metadata.
    
    Attributes:
        plugin_class: The plugin class or module path
        name: Unique identifier for this plugin instance
        config: Configuration dictionary for the plugin
        version: Version of the plugin
        **kwargs: Additional metadata
    """
    plugin_class: Any
    name: str
    options: Dict[str, Any]
    version: str = "1.0"
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "plugin_class": _get_class_path(self.plugin_class) if not isinstance(self.plugin_class, str) else self.plugin_class,
            "name": self.name,
            "options": self.options,
            "version": self.version,
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PluginDescriptor':
        """Deserialize from dictionary."""
        plugin_class = data["plugin_class"]
        # If it's a string, try to import it
        if isinstance(plugin_class, str):
            try:
                plugin_class = _import_class(plugin_class)
            except (ImportError, AttributeError):
                # Keep as string if import fails
                pass
        
        return cls(
            plugin_class=plugin_class,
            name=data["name"],
            options=data.get("options", {}),
            version=data.get("version", "1.0"),
            metadata=data.get("metadata", {}),
        )


@dataclass
class ServicePlugins:
    """
    Flat list of PluginDescriptor instances.
    Services run in parallel processes.
    
    Attributes:
        plugins: List of PluginDescriptor instances
    """
    plugins: List[PluginDescriptor] = field(default_factory=list)
    
    def add(self, plugin: PluginDescriptor) -> None:
        """Add a plugin descriptor to services."""
        self.plugins.append(plugin)
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "plugins": [p.to_dict() for p in self.plugins]
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ServicePlugins':
        """Deserialize from dictionary."""
        plugins = [PluginDescriptor.from_dict(p) for p in data.get("plugins", [])]
        return cls(plugins=plugins)


@dataclass
class ParallelPlugins:
    """
    Container for plugins/steps to execute in parallel.
    
    Attributes:
        items: List of PluginDescriptor, SequentialPlugins, or ParallelPlugins
    """
    items: List[Union['PluginDescriptor', 'SequentialPlugins', 'ParallelPlugins']] = field(default_factory=list)
    
    def add(self, item: Union['PluginDescriptor', 'SequentialPlugins', 'ParallelPlugins']) -> None:
        """Add a plugin, sequential, or parallel item."""
        self.items.append(item)
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        items = []
        for item in self.items:
            if isinstance(item, PluginDescriptor):
                items.append({"type": "descriptor", "data": item.to_dict()})
            elif isinstance(item, SequentialPlugins):
                items.append({"type": "sequential", "data": item.to_dict()})
            elif isinstance(item, ParallelPlugins):
                items.append({"type": "parallel", "data": item.to_dict()})
        return {"items": items}
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ParallelPlugins':
        """Deserialize from dictionary."""
        items = []
        for item_data in data.get("items", []):
            item_type = item_data.get("type")
            item_value = item_data.get("data")
            
            if item_type == "descriptor":
                items.append(PluginDescriptor.from_dict(item_value))
            elif item_type == "sequential":
                items.append(SequentialPlugins.from_dict(item_value))
            elif item_type == "parallel":
                items.append(ParallelPlugins.from_dict(item_value))
        
        return cls(items=items)


@dataclass
class SequentialPlugins:
    """
    Container for plugins/steps to execute sequentially in the same process.
    Can contain PluginDescriptor, SequentialPlugins, or ParallelPlugins.
    
    Attributes:
        items: List of PluginDescriptor, SequentialPlugins, or ParallelPlugins
    """
    items: List[Union[PluginDescriptor, 'SequentialPlugins', ParallelPlugins]] = field(default_factory=list)
    
    def add(self, item: Union[PluginDescriptor, 'SequentialPlugins', ParallelPlugins]) -> None:
        """Add a plugin, sequential, or parallel item."""
        self.items.append(item)
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        items = []
        for item in self.items:
            if isinstance(item, PluginDescriptor):
                items.append({"type": "descriptor", "data": item.to_dict()})
            elif isinstance(item, SequentialPlugins):
                items.append({"type": "sequential", "data": item.to_dict()})
            elif isinstance(item, ParallelPlugins):
                items.append({"type": "parallel", "data": item.to_dict()})
        return {"items": items}
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SequentialPlugins':
        """Deserialize from dictionary."""
        items = []
        for item_data in data.get("items", []):
            item_type = item_data.get("type")
            item_value = item_data.get("data")
            
            if item_type == "descriptor":
                items.append(PluginDescriptor.from_dict(item_value))
            elif item_type == "sequential":
                items.append(SequentialPlugins.from_dict(item_value))
            elif item_type == "parallel":
                items.append(ParallelPlugins.from_dict(item_value))
        
        return cls(items=items)


@dataclass
class PluginPackage:
    """
    Configuration package for plugin manager and trial.
    
    Attributes:
        services: ServicePlugins - flat list of service plugins
        steps: SequentialPlugins - hierarchical execution steps
    """
    services: ServicePlugins = field(default_factory=ServicePlugins)
    steps: SequentialPlugins = field(default_factory=SequentialPlugins)
    
    def add_service(self, plugin: PluginDescriptor) -> None:
        """Add a plugin to services."""
        self.services.add(plugin)
    
    def add_step(self, item: Union[PluginDescriptor, SequentialPlugins, ParallelPlugins]) -> None:
        """Add an item to execution steps."""
        self.steps.add(item)
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "services": self.services.to_dict(),
            "steps": self.steps.to_dict(),
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PluginPackage':
        """Deserialize from dictionary."""
        services = ServicePlugins.from_dict(data.get("services", {}))
        steps = SequentialPlugins.from_dict(data.get("steps", {}))
        return cls(services=services, steps=steps)
    
    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), indent=2)
    
    @classmethod
    def from_json(cls, json_str: str) -> 'PluginPackage':
        """Deserialize from JSON string."""
        data = json.loads(json_str)
        return cls.from_dict(data)
    
    def save(self, filepath: Union[str, Path]) -> None:
        """Save configuration to JSON file."""
        filepath = Path(filepath)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        filepath.write_text(self.to_json())
    
    @classmethod
    def load(cls, filepath: Union[str, Path]) -> 'PluginPackage':
        """Load configuration from JSON file."""
        filepath = Path(filepath)
        json_str = filepath.read_text()
        return cls.from_json(json_str)